#include <BlynkSimpleShieldEsp8266.h>

boolean v0pin = false;
boolean v1pin = false;
boolean v2pin = false;
boolean v3pin = false;
boolean v4pin = false;
boolean v5pin = false;
boolean v6pin = false;
boolean v7pin = false;
boolean v8pin = false;
boolean v9pin = false;
boolean v10pin = false;
boolean v11pin = false;
boolean v12pin = false;
boolean v13pin = false;
boolean v14pin = false;
boolean v15pin = false;
boolean v16pin = false;
boolean v17pin = false;
boolean v18pin = false;
boolean v19pin = false;
boolean v20pin = false;

double v0data;
double v1data;
double v2data;
double v3data;
double v4data;
double v5data;
double v6data;
double v7data;
double v8data;
double v9data;
double v10data;
double v11data;
double v12data;
double v13data;
double v14data;
double v15data;
double v16data;
double v17data;
double v18data;
double v19data;
double v20data;

void myTimerEvent(){
  if (v0pin){
    Blynk.virtualWrite(V0,v0data);
  }
  if (v1pin){
    Blynk.virtualWrite(V1,v1data);
  }
  if (v2pin){
    Blynk.virtualWrite(V2,v2data);
  }
  if (v3pin){
    Blynk.virtualWrite(V3,v3data);
  }
  if (v4pin){
    Blynk.virtualWrite(V4,v4data);
  }
  if (v5pin){
    Blynk.virtualWrite(V5,v5data);
  }
  if (v6pin){
    Blynk.virtualWrite(V6,v6data);
  }
  if (v7pin){
    Blynk.virtualWrite(V7,v7data);
  }
  if (v8pin){
    Blynk.virtualWrite(V8,v8data);
  }
  if (v9pin){
    Blynk.virtualWrite(V9,v9data);
  }
  if (v10pin){
    Blynk.virtualWrite(V10,v10data);
  }
  if (v11pin){
    Blynk.virtualWrite(V11,v11data);
  }
  if (v12pin){
    Blynk.virtualWrite(V12,v12data);
  }
  if (v13pin){
    Blynk.virtualWrite(V13,v13data);
  }
  if (v14pin){
    Blynk.virtualWrite(V14,v14data);
  }
  if (v15pin){
    Blynk.virtualWrite(V15,v15data);
  }
  if (v16pin){
    Blynk.virtualWrite(V16,v16data);
  }
  if (v17pin){
    Blynk.virtualWrite(V17,v17data);
  }
  if (v18pin){
    Blynk.virtualWrite(V18,v18data);
  }
  if (v19pin){
    Blynk.virtualWrite(V19,v19data);
  }
  if (v20pin){
    Blynk.virtualWrite(V20,v20data);
  }
}
