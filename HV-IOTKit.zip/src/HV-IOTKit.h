#include <BlynkSimpleShieldEsp8266.h>

boolean v0pin = false;
boolean v1pin = false;
boolean v2pin = false;
boolean v3pin = false;
boolean v4pin = false;
boolean v5pin = false;
boolean v6pin = false;
boolean v7pin = false;
boolean v8pin = false;
boolean v9pin = false;
boolean v10pin = false;
boolean v11pin = false;
boolean v12pin = false;
boolean v13pin = false;
boolean v14pin = false;
boolean v15pin = false;
boolean v16pin = false;
boolean v17pin = false;
boolean v18pin = false;
boolean v19pin = false;
boolean v20pin = false;
boolean v21pin = false;
boolean v22pin = false;
boolean v23pin = false;
boolean v24pin = false;
boolean v25pin = false;
boolean v26pin = false;
boolean v27pin = false;
boolean v28pin = false;
boolean v29pin = false;
boolean v30pin = false;
boolean v31pin = false;
boolean v32pin = false;
boolean v33pin = false;
boolean v34pin = false;
boolean v35pin = false;
boolean v36pin = false;
boolean v37pin = false;
boolean v38pin = false;
boolean v39pin = false;
boolean v40pin = false;
boolean v41pin = false;
boolean v42pin = false;
boolean v43pin = false;
boolean v44pin = false;
boolean v45pin = false;
boolean v46pin = false;
boolean v47pin = false;
boolean v48pin = false;
boolean v49pin = false;
boolean v50pin = false;

double v0data;
double v1data;
double v2data;
double v3data;
double v4data;
double v5data;
double v6data;
double v7data;
double v8data;
double v9data;
double v10data;
double v11data;
double v12data;
double v13data;
double v14data;
double v15data;
double v16data;
double v17data;
double v18data;
double v19data;
double v20data;
double v21data;
double v22data;
double v23data;
double v24data;
double v25data;
double v26data;
double v27data;
double v28data;
double v29data;
double v30data;
double v31data;
double v32data;
double v33data;
double v34data;
double v35data;
double v36data;
double v37data;
double v38data;
double v39data;
double v40data;
double v41data;
double v42data;
double v43data;
double v44data;
double v45data;
double v46data;
double v47data;
double v48data;
double v49data;
double v50data;

void myTimerEvent(){
  if (v0pin){
    Blynk.virtualWrite(V0,v0data);
  }
  if (v1pin){
    Blynk.virtualWrite(V1,v1data);
  }
  if (v2pin){
    Blynk.virtualWrite(V2,v2data);
  }
  if (v3pin){
    Blynk.virtualWrite(V3,v3data);
  }
  if (v4pin){
    Blynk.virtualWrite(V4,v4data);
  }
  if (v5pin){
    Blynk.virtualWrite(V5,v5data);
  }
  if (v6pin){
    Blynk.virtualWrite(V6,v6data);
  }
  if (v7pin){
    Blynk.virtualWrite(V7,v7data);
  }
  if (v8pin){
    Blynk.virtualWrite(V8,v8data);
  }
  if (v9pin){
    Blynk.virtualWrite(V9,v9data);
  }
  if (v10pin){
    Blynk.virtualWrite(V10,v10data);
  }
  if (v11pin){
    Blynk.virtualWrite(V11,v11data);
  }
  if (v12pin){
    Blynk.virtualWrite(V12,v12data);
  }
  if (v13pin){
    Blynk.virtualWrite(V13,v13data);
  }
  if (v14pin){
    Blynk.virtualWrite(V14,v14data);
  }
  if (v15pin){
    Blynk.virtualWrite(V15,v15data);
  }
  if (v16pin){
    Blynk.virtualWrite(V16,v16data);
  }
  if (v17pin){
    Blynk.virtualWrite(V17,v17data);
  }
  if (v18pin){
    Blynk.virtualWrite(V18,v18data);
  }
  if (v19pin){
    Blynk.virtualWrite(V19,v19data);
  }
  if (v20pin){
    Blynk.virtualWrite(V20,v20data);
  }
if (v21pin){
    Blynk.virtualWrite(V21,v21data);
  }
if (v22pin){
    Blynk.virtualWrite(V22,v22data);
  }
if (v23pin){
    Blynk.virtualWrite(V23,v23data);
  }
if (v24pin){
    Blynk.virtualWrite(V24,v24data);
  }
if (v25pin){
    Blynk.virtualWrite(V25,v25data);
  }
if (v26pin){
    Blynk.virtualWrite(V26,v26data);
  }
if (v27pin){
    Blynk.virtualWrite(V27,v27data);
  }
if (v28pin){
    Blynk.virtualWrite(V28,v28data);
  }
if (v29pin){
    Blynk.virtualWrite(V29,v29data);
  }
if (v30pin){
    Blynk.virtualWrite(V30,v30data);
  }
if (v31pin){
    Blynk.virtualWrite(V31,v31data);
  }
if (v32pin){
    Blynk.virtualWrite(V32,v32data);
  }
if (v33pin){
    Blynk.virtualWrite(V33,v33data);
  }
if (v34pin){
    Blynk.virtualWrite(V34,v34data);
  }
if (v35pin){
    Blynk.virtualWrite(V35,v35data);
  }
if (v36pin){
    Blynk.virtualWrite(V36,v36data);
  }
if (v37pin){
    Blynk.virtualWrite(V37,v37data);
  }
if (v38pin){
    Blynk.virtualWrite(V38,v38data);
  }
if (v39pin){
    Blynk.virtualWrite(V39,v39data);
  }
if (v40pin){
    Blynk.virtualWrite(V40,v40data);
  }
if (v41pin){
    Blynk.virtualWrite(V41,v41data);
  }
if (v42pin){
    Blynk.virtualWrite(V42,v42data);
  }
if (v43pin){
    Blynk.virtualWrite(V43,v43data);
  }
if (v44pin){
    Blynk.virtualWrite(V44,v44data);
  }
if (v45pin){
    Blynk.virtualWrite(V45,v45data);
  }
if (v46pin){
    Blynk.virtualWrite(V46,v46data);
  }
if (v47pin){
    Blynk.virtualWrite(V47,v47data);
  }
if (v48pin){
    Blynk.virtualWrite(V48,v48data);
  }
if (v49pin){
    Blynk.virtualWrite(V49,v49data);
  }
if (v50pin){
    Blynk.virtualWrite(V50,v50data);
  }
}
